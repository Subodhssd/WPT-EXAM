const express = require("express");
const app = express();
const { selectAllUser, addUser } = require("./user");
app.use(express.json());
const cors = require("cors");
app.use(cors());

//http://localhost:4000/users
app.get("/users", async (req, res) => {
    const list = await selectAllUser();
    // console.log(req.query);
    res.json(list);
});

// http://localhost:4000/msg
app.post("/msg", async (req, res) => {
    const list = await selectAllUser();
    console.log(req.body);
    const user = req.body;
    await addUser(user);
    res.json({ message: "Message added sucesfully" });
});

app.listen(4000, () => console.log("Server Started sucesfully"));


