const mysql = require("mysql");
const Promise = require("bluebird");
Promise.promisifyAll(require("mysql/lib/Connection").prototype);

const dbinfo = {
    host: "localhost",
    user: "root",
    password: "cdac",
    database: "exam",
};

async function connectionCheck() {
    const connection = mysql.createConnection(dbinfo);
    await connection.connectAsync();
    console.log("Connection Success");
    await connection.endAsync();
}

const selectAllUser = async () => {
    const connection = mysql.createConnection(dbinfo);
    await connection.connectAsync();
    let sql = 'select * from user1';
    const list = await connection.queryAsync(sql);
    console.log("Connection Success");

    await connection.endAsync();
    return list;
}


async function addUser(user1) {
    const connection = mysql.createConnection(dbinfo);
    await connection.connectAsync();
    let sql = `insert into user1(username,message) values(?,?)`;
    await connection.queryAsync(sql, [user1.username, user1.message]);
    await connection.endAsync();
    console.log("Message Added");
}

connectionCheck();

const user = {
    username: "M.Gandhi",
    message: "Non-Violence"
};

addUser(user);

module.exports = { selectAllUser, addUser };

