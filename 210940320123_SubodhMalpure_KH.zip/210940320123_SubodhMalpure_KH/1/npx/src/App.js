export default function App() {
  return (
    <>
      <Header />
      <Whatsapp />
    </>
  );
}

function Header() {
  return (
    <div>
      <div className="bg-dark text-light p-3 m-3">
        MyChatApp
        <div>by(Subodh Malpure)(123_Subodh_KH)</div>
      </div>
    </div>
  );
}

function Whatsapp() {
  return (
    <div className="">
      <input className="m-3 p-3" type="text" placeholder="Lets chat here..." />
      <input className="p-3" type="button" value="SEND" />
    </div>
  );
}
